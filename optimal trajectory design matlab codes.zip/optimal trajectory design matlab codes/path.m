function path = path(X,U,p)
    path = [];
end