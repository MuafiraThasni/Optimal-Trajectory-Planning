clc
clear
close all
pi=3.14;
p.func.deriv = @ddmrcgl_deriv; % derivative function name
p.func.lagrange = @ddmrcgl_lagrange; % Lagrange term function name
p.func.mayer = @ddmrcgl_mayer; % Mayer term function name
p.func.path = @ddmrcgl_path; % path constraint function name
p.func.boundary = @ddmrcgl_boundary; % boundary constraint function name
p.func.plot = @ddmrcgl_plot; % plot function name
p.func.bounds = @ddmrcgl_bounds; % variables bounds function name
p.func.initial = @ddmrcgl_initial; % initial guess function name
% problem specific parameters
prob.d=0.04;
prob.x0 = 5; prob.y0 = 6; prob.theta0 = pi/3; prob.v0=0; prob.w0=0; % initial conditions
prob.xf = 50; prob.yf = 50; prob.thetaf=0; prob.vf=0; prob.wf=0; % final conditions
prob.tmax = 150; % maximum allowable tf
prob.t0 = 0; % initial time (required)
prob.tf = 500; % final time (required)
p.prob = prob;
%t=p.tf;
p.ns = 5; % states
p.nu = 2; % controls
% variable final time problem
p.varTF = 1; % 0:no, 1:yes
%--- options ---%
% pseudospectral method
p.opts.method = 'CGL'; % either LGL or CGL
% scale problem
p.opts.scale = 0; % 0:no, 1:yes
% plot flag
p.opts.plotflag = 1; % 0:no, 1:yes
% save flag
p.opts.saveflag = 1; % 0:no, 1:yes
% additional fmincon options
p.opts.fmincon.MaxIter = 2000;
% mesh number
mesh = 2;
% switch statement for case studies
switch mesh
    case 1
        p.Tarray = [0,1]; % segment boundaries
        p.Narray = 5; % number of nodes per segment (same size as p.Tarray)
    case 2
        p.Tarray = [0,1]; % segment boundaries
        p.Narray = 8; % number of nodes per segment
    case 3
        p.Tarray = [0,1]; % segment boundaries
        p.Narray = 9; % number of nodes per segment
    case 4
        p.Tarray = [0,1]; % segment boundaries
        p.Narray = 20; % number of nodes per segment
    case 5
        p.Tarray = linspace(0,1,3); % segment boundaries
        p.Narray = 10*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment
    case 6
        p.Tarray = linspace(0,1,3); % segment boundaries
        p.Narray = 3*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment
    case 7
        p.Tarray = linspace(0,1,3); % segment boundaries
        p.Narray = 4*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment
    case 8
        p.Tarray = linspace(0,1,4); % segment boundaries
        p.Narray = 6*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment
    case 9
        p.Tarray = linspace(0,1,6); % segment boundaries
        p.Narray = 5*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment
    case 10
        p.Tarray = linspace(0,1,8); % segment boundaries
        p.Narray = 4*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment
end
[t,X,U,f,p,ef] = PS_Solve(p);
%interpolation 
 for i = 1:length(p.Narray)
        % interpolate based on method
        tarray1{i} = linspace(p.t0(i),p.tf(i),2000);
        interpX1{1,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),1)',tarray1{i});
        interpX1{2,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),2)',tarray1{i});
        interpX1{3,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),3)',tarray1{i});
        interpX1{4,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),4)',tarray1{i});
        interpX1{5,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),5)',tarray1{i});
        interpU1{1,i} = LagrangeInter(p.t{i}',U(p.cumN(i)+1:p.cumN(i+1),1)',tarray1{i});
        interpU1{2,i} = LagrangeInter(p.t{i}',U(p.cumN(i)+1:p.cumN(i+1),2)',tarray1{i});
 end
  tarray = cell2mat(tarray1)';
    interpX = cell2mat(interpX1)';
    interpU = cell2mat(interpU1)';
    
    %plots....................
    
    
   %trajectory
   figure
   plot(interpX(:,1),interpX(:,2),'linewidth',1)
   hold on
   plot(X(:,1),X(:,2),'linewidth',1.5,'linestyle','none','Marker','o')
   xlabel('x (m)')
   ylabel('y (m)')
   title('Trajectory')
   legend('trajectory','CGL nodes')
   
    figure
    h1 = plot(tarray,interpX,'linewidth',1); hold on
  h1(1).Color = [1 0 0];
    h1(2).Color = [0 0 1];
    h1(3).Color = [0 0 0];
    h1(4).Color = [1 0 1];
    h1(5).Color = [0.01 0.9 1];
    % plot CGL nodes
    h2 = plot(t,X,'linestyle','none','Marker','o','linewidth',1); 
 h2(1).Color = [1 0 0];
    h2(2).Color = [0 0 1];
    h2(3).Color = [0 0 0];
    h2(4).Color = [1 0 1];
    h2(5).Color = [0,01 0.9 0];
legend('x','y','$\phi$','v','$\omega$','x-CGL','y-CGL','$\phi-CGL$','v-CGL','$\omega$-CGL','interpreter','latex')
xlabel('time (s)')
ylabel('x(m) , y(m), $\phi$(rad) , v(m/s), $\omega$(rad/s)','interpreter','latex')
figure
    h3=plot(tarray,interpU,'linewidth',1);
    hold on;
    h4 = plot (t,U,'linestyle','none','Marker','o','linewidth',1);
    legend('$u_1$','$u_2$','$u_1-CGL$','$u_2-CGL$','interpreter','latex')
    





