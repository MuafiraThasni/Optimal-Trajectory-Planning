function path = ddmr_path(X,U,p)
    path = [];
end