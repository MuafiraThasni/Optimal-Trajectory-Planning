x0=0;
f = zeros(size(x0))
a=
xnew = linprog(f,A,b,Aeq,beq,lb,ub);