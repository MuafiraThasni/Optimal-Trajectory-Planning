%-------------------------------------------------------------------
% msavename.m
% Same as mfoldername, maintained for backwards compatibility
%--------------------------------------------------------------------------
function [path_name] = msavename(fun_path,extra_path)

    [path_name] = mfoldername(fun_path,extra_path);

end