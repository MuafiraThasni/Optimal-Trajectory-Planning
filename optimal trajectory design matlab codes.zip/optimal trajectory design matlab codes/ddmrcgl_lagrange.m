function L = ddmrcgl_lagrange(x,p,i)
    
    X = reshape(x(1:p.ns*p.nt),p.nt,[]); % states
    U = reshape(x(p.ns*p.nt+1:end-1),p.nt,[]); % controls
   
    L = ones(p.Narray(i),1);
    
end