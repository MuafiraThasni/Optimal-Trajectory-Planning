function path = ddmrcgl_path(X,U,p)
    path = [];
end